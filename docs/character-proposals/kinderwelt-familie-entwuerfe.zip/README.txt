Vier Figurenentwuerfe fuer Kinderwelt: Mischa, Du, Mama und Katze.
Noch nicht in die App eingebaut. Originalfotos sind nicht enthalten.
Alle PNGs: 1024 x 1536 Pixel mit Transparenz.
