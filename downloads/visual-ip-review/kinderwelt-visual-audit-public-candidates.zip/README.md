# Private owner review: non-sensitive candidates

Nothing has been submitted to an image-search or external vision service.
Every queue row starts `not_searched` and `online_upload_permitted=false`.
The owner must approve a specific non-sensitive candidate before any upload.
This pack does not authorize uploading family/private or unclassified material.

After your specific approval, manual Google Lens / Google Images steps:
1. Open images.google.com in your own browser and select the camera/Lens control.
2. Upload only the approved file from this folder's candidates directory.
   Use the individual atlas crop when the full sheet hides the element.
3. Inspect visually similar results and open the original publication pages.
   A repost, stock aggregator or AI gallery is not sufficient source evidence.
4. Trace the earliest credible author/source; check dates, original files,
   license version and attribution/share-alike/non-commercial/no-derivatives
   restrictions. Copyright, trademark and personality rights are separate.
5. Record URLs, access date, screenshots/notes and your decision in the local
   queue. Keep any newly discovered private information out of Git/CI.
6. A search with no hits is not clearance. Resemblance alone is not proof of
   infringement. Obtain the missing rights/evidence or seek qualified advice
   before deciding whether a specific asset needs replacement.

Do not publish this pack, its contact sheets or its ZIP as a repository artifact.
