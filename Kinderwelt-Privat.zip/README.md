# Kinderwelt – private Familienfiguren

Dieses Repository muss **privat** bleiben. Es enthält ausschließlich sechs KI-generierte Familienfiguren und ihre Kostümatlanten sowie zwei Kataloge (14 Dateien). Keine Originalfotos, Sprachaufnahmen, Zugangsdaten oder Android-Signaturschlüssel. Das Eichhörnchen ist eine gemeinsame Fantasiefigur im Hauptrepository.

Der Hauptcode liegt in `sayac007/Kinderwelt`. GitHub Actions dort liest nur eine ausdrücklich festgelegte Commit-Version dieses privaten Repositorys. Ein eigener Fine-grained Token benötigt ausschließlich Contents: Read für dieses Repository; er wird im Hauptrepository als `KINDERWELT_FAMILY_ASSETS_TOKEN` gespeichert.

`manifest.json` enthält Größe und SHA256 jeder erlaubten Datei. Veränderungen erfordern einen neuen geprüften Commit und einen aktualisierten Verweis im Hauptrepository. Die intern stabilen Figurenkennungen bleiben erhalten.
